var game = new Phaser.Game(document.getElementById("karel-board").offsetWidth, window.innerHeight, Phaser.AUTO, 'karel-board', {
  init: init,
  preload: preload,
  create: create
});

var gameProperties = {
  screenWidth: document.getElementById("karel-board").offsetWidth,
  screenHeight: window.innerHeight,

  tileWidth: 64,
  tileHeight: 64,

  boardWidth: 0,
  boardHeight: 0,

  backgroundColor: "#FFFFFF",
};

var graphicAssets = {
  tile: {
    URL: 'assets/frames.png',
    name: 'tile',
	  frames: 15
  },
};

function preload() {
  game.load.spritesheet(graphicAssets.tile.name, graphicAssets.tile.URL, gameProperties.tileWidth, gameProperties.tileHeight, graphicAssets.tile.frames);
  game.load.text('text', 'board.txt');
}

var board;
var boardTop;
var boardLeft;

var fileInput = document.getElementById('board-input');
var table;
var karelPos = new Array(2);
var karelOr;

fileInput.addEventListener('change', function(e) {
  e.preventDefault();
  var file = fileInput.files[0];
  var textType = /text.*/;

  if (file.type.match(textType)) {
    var reader = new FileReader();

    reader.onload = function(e) {
      table = reader.result;
      table = table.split("\n");
      for (var i = 0; i < table.length; i++) {
        table[i] = table[i].split(" ");
      }
      table.pop();
      gameProperties.boardWidth = table[0].length;
      gameProperties.boardHeight = table.length;
      for (var x = 0; x < gameProperties.boardWidth; x++) {
        for (var y = 0; y < gameProperties.boardHeight; y++) {
          if (table[y][x] == "n" || table[y][x] == "s" || table[y][x] == "e" || table[y][x] == "o") {
            karelPos[0] = x;
            karelPos[1] = y;
            karelOr = table[y][x];
            table[y][x] = "-";
          }
        }
      }
      restartBoard();
      init();
    }

    reader.readAsText(file);
  } else {
    alert("Algo anda mal con el archivo");
  }
});

function init() {
  boardTop = (gameProperties.screenHeight - (gameProperties.tileHeight * gameProperties.boardHeight)) * 0.5;
  boardLeft = (gameProperties.screenWidth - (gameProperties.tileWidth * gameProperties.boardWidth)) * 0.5;
  initBoard();
  //var ic = [100, 2, 1000, 1000, 2000, 5000];
  //semantic(ic);
}

function create() {

}

function update() {

}

function semantic(ic, actual) {
	while (ic[actual] != 5000){
      switch (ic[actual]) {
		// jump
        case 100:
		  actual = ic[actual + 1];
          break;
		// move
        case 1000:
          currentFrame = 1;
          break;
		// turnLeft
        case 2000:
          currentFrame = 2;
          break;
	    // pickBeeper
        case 3000:
	      actual = ic[actual + 1];
          break;
	    // putBeeper
        case 4000:
          currentFrame = 1;
          break;
	    // end
        case 5000:
          currentFrame = 2;
          break;
	  }
	}
}

function move() {
	
}

function turnLeft() {
	
}

function pickBeeper() {
	
}

function putBeeper() {
	
}

function frontIsClear() {
    switch (karelOr) {
      case "n":
		if(karelPos[1] - 1 < 0){
		  return false;
		} else {
		  return (table[karelPos[1] - 1][karelPos[0]] != "p");
		}
      case "e":
	    if(karelPos[0] + 1 >= gameProperties.boardWidth){
		  return false;
	    } else {
		  return table[karelPos[1]][karelPos[0] + 1] != "p";
	    }
      case "s":
	    if(karelPos[1] + 1 >= gameProperties.boardHeight){
	      return false;
	    } else {
	      return table[karelPos[1] + 1][karelPos[0]] != "p";
	    }
      case "o":
        if(karelPos[0] - 1 < 0){
	      return false;
        } else {
	      return table[karelPos[1]][karelPos[0] - 1] != "p";
        }
	} 
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function initBoard() {
  board = new Board(gameProperties.boardWidth, gameProperties.boardHeight, table, karelPos, karelOr);
  board.moveTo(boardLeft, boardTop);
  game.stage.backgroundColor = gameProperties.backgroundColor;
  console.log(frontIsClear());
  console.log(0);
  sleep(2000).then(() => {
	  console.log(2);
  });  
  
}

function refreshBoard() {
  board = new Board(gameProperties.boardWidth, gameProperties.boardHeight, table, karelPos, karelOr);
}

function restartBoard() {
  game.world.removeAll()
}
